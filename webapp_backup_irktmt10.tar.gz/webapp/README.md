# FinMatch - نظام مقارنة الكشوفات المالية 🔬

## نظرة عامة

**FinMatch** هو نظام ذكي لمقارنة الكشوفات المالية (Excel/PDF) وفقاً لمعايير صارمة، مع إنتاج تقارير تحليلية مفصلة بالعمليات غير المطابقة.

### المزايا الرئيسية
- ✅ **معالجة محلية كاملة**: لا يتم رفع أي بيانات للسيرفر (Client-Side Processing)
- ✅ **خصوصية تامة**: جميع البيانات تبقى في متصفحك فقط
- ✅ **دعم Excel**: يدعم تنسيقات .xlsx و .xls
- ✅ **6 معايير مطابقة**: مقارنة صارمة وفق معايير محاسبية دقيقة
- ✅ **تقارير احترافية**: تصدير JSON و HTML مع تحليل تفصيلي
- ✅ **واجهة عربية**: تصميم حديث متجاوب بالكامل بالعربية

---

## 🌐 الروابط

### 🔗 التطبيق المباشر
**Sandbox (Development):**  
https://3000-irktmt10704tmrt5vwrnc-2e77fc33.sandbox.novita.ai

**API Health Check:**  
https://3000-irktmt10704tmrt5vwrnc-2e77fc33.sandbox.novita.ai/api/health

### 📦 الإنتاج (بعد النشر)
- **Cloudflare Pages**: سيتم نشره قريباً
- **GitHub**: سيتم ربطه بمستودع GitHub

---

## 🏗️ البنية المعمارية

### التقنيات المستخدمة
```
Frontend (Client-Side):
├── HTML5 + Tailwind CSS
├── Vanilla JavaScript (ES6+)
├── SheetJS (xlsx) - لمعالجة Excel
└── Font Awesome - للأيقونات

Backend (Edge Runtime):
├── Hono Framework v4.10.4
├── Cloudflare Workers/Pages
├── TypeScript v5.0+
└── Vite v6.3.5 (Build Tool)
```

### هيكل المشروع
```
webapp/
├── src/
│   └── index.tsx                 # Hono application
├── public/
│   └── static/
│       ├── finmatch.js           # محرك المعالجة والمقارنة
│       ├── app.js                # التحكم في الواجهة
│       └── style.css             # أنماط مخصصة
├── dist/                         # ملفات الإنتاج (بعد البناء)
├── ecosystem.config.cjs          # PM2 configuration
├── wrangler.jsonc                # Cloudflare configuration
├── package.json
├── vite.config.ts
└── README.md
```

---

## 📊 معايير المطابقة الستة

يقوم النظام بمقارنة كل سجل مالي وفقاً للشروط التالية:

| # | المعيار | التفاصيل |
|---|---------|----------|
| 1️⃣ | **مطابقة العملة** | يجب تطابق العملة 100% (USD, EGP, SAR...) |
| 2️⃣ | **مطابقة الطبيعة** | يجب تطابق نوع المبلغ (مدين/دائن) |
| 3️⃣ | **مطابقة المبلغ** | يجب تطابق المبلغ بدقة 100% |
| 4️⃣ | **فرق التاريخ** | يجب ألا يزيد الفرق عن **7 أيام** |
| 5️⃣ | **تشابه نوع العملية** | يجب أن يكون التشابه ≥ **80%** (Jaccard Similarity) |
| 6️⃣ | **تشابه البيان** | يجب أن يكون التشابه ≥ **50%** (Jaccard Similarity) |

**ملاحظة**: يعتبر السجل "مطابق" فقط إذا استوفى **جميع** الشروط الستة.

---

## 💾 نموذج البيانات

### تنسيق الملفات المدعومة

#### Excel (.xlsx, .xls)
يتم الكشف التلقائي عن الأعمدة حسب الأسماء:

```
التاريخ | المبلغ | مدين | دائن | نوع العملية | البيان | العملة | الطبيعة
--------|--------|------|-------|-------------|--------|--------|--------
```

**ملاحظات هامة:**
- يتم تجاهل الترويسات والهوامش والأعمدة الإضافية (مثل الرصيد، المرجع)
- يتم دعم تنسيق "عمودين" حيث يظهر المبلغ في عمود "مدين" أو "دائن"
- يتم تجاهل المبالغ الصفرية
- إذا ذكرت العملة مرة واحدة في الترويسة، يتم تطبيقها على جميع السجلات

#### مثال على Excel صحيح:
```
التاريخ       | مدين    | دائن   | البيان                | العملة
-------------|---------|--------|----------------------|-------
01/01/2024   | 1000.00 |        | دفعة إيجار           | EGP
02/01/2024   |         | 500.00 | إيراد خدمات          | EGP
```

---

## 🔧 التثبيت والتشغيل

### المتطلبات
- Node.js v18+
- npm v9+

### 1. Clone المشروع
```bash
git clone <repository-url>
cd webapp
```

### 2. تثبيت المكتبات
```bash
npm install
```

### 3. التشغيل في بيئة التطوير (Sandbox)
```bash
# بناء التطبيق أولاً
npm run build

# تشغيل باستخدام PM2
pm2 start ecosystem.config.cjs

# أو التشغيل المباشر
npm run dev:sandbox
```

### 4. التشغيل المحلي (Vite Dev Server)
```bash
npm run dev
```

---

## 🚀 النشر على Cloudflare Pages

### الخطوات:

#### 1. إعداد Cloudflare API Token
```bash
# استدعاء أداة الإعداد التلقائي
# (في sandbox environment)
setup_cloudflare_api_key
```

#### 2. البناء والنشر
```bash
# بناء للإنتاج
npm run build

# نشر على Cloudflare Pages
npm run deploy:prod

# أو يدوياً:
npx wrangler pages deploy dist --project-name finmatch
```

#### 3. إنشاء المشروع (أول مرة فقط)
```bash
npx wrangler pages project create finmatch \
  --production-branch main \
  --compatibility-date 2024-01-01
```

---

## 📖 دليل الاستخدام

### 1. رفع الملفات
1. افتح التطبيق في المتصفح
2. اختر **الكشف الأول** (ملف Excel)
3. اختر **الكشف الثاني** (ملف Excel)

### 2. بدء المقارنة
- اضغط على زر **"بدء المقارنة"**
- سيتم المعالجة في ثوانٍ (حسب حجم الملفات)

### 3. عرض النتائج
ستظهر لك:
- **ملخص النتائج**: إحصائيات عامة
- **نسبة المطابقة**: النسبة المئوية للسجلات المتطابقة
- **قائمة العمليات غير المطابقة**: تفاصيل كل سجل فشل في المطابقة

### 4. التصدير
- **تصدير JSON**: للتكامل مع أنظمة أخرى
- **تصدير HTML**: لطباعة التقرير أو مشاركته

---

## 📝 مثال على JSON Response

```json
{
  "report_id": "550e8400-e29b-41d4-a716-446655440000",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "processing_time_ms": 1250,
  "file1_name": "statement_jan.xlsx",
  "file2_name": "statement_feb.xlsx",
  "total_records_file1": 150,
  "total_records_file2": 148,
  "matching_entries": 145,
  "match_rate": "96.67%",
  "non_matching_entries": [
    {
      "file1_entry": {
        "date": "2024-01-05T00:00:00.000Z",
        "amount": 1500.00,
        "nature": "debit",
        "operationType": "دفعة إيجار",
        "description": "إيجار شهر يناير",
        "currency": "EGP",
        "_rowIndex": 15,
        "_sourceFile": "statement_jan.xlsx"
      },
      "file2_candidates": [
        {
          "record": { /* أقرب سجل مطابق */ },
          "score": 75.5,
          "checks": {
            "currency": true,
            "nature": true,
            "amount": false,
            "date": true,
            "operationType": true,
            "description": true
          }
        }
      ],
      "failure_reasons": {
        "amount_mismatch": true,
        "nature_mismatch": false,
        "currency_mismatch": false,
        "date_diff_exceeds_7_days": false,
        "operation_type_similarity_lt_80": false,
        "description_similarity_lt_50": false
      }
    }
  ]
}
```

---

## 🛡️ الأمان والخصوصية

### ضمانات الأمان
- ✅ **لا رفع للسيرفر**: جميع الملفات تُعالج في المتصفح فقط
- ✅ **لا تخزين**: لا يتم حفظ أي بيانات على أي خادم
- ✅ **معالجة في الذاكرة**: البيانات تُحذف فور إغلاق الصفحة
- ✅ **فلترة الملفات**: يتم رفض الامتدادات الخطرة (.exe, .bat...)

### قيود التشغيل
- حجم الملف: موصى به < 5 MB (قيود المتصفح)
- عدد السجلات: موصى به < 5000 سجل لكل ملف

---

## 🧪 الاختبار

### اختبار API
```bash
curl http://localhost:3000/api/health
```

**الاستجابة المتوقعة:**
```json
{
  "status": "ok",
  "service": "FinMatch",
  "version": "1.0.0",
  "timestamp": "2024-01-15T10:00:00.000Z"
}
```

---

## 📦 الأوامر المتاحة

```bash
npm run dev              # تشغيل Vite dev server
npm run dev:sandbox      # تشغيل wrangler dev (sandbox)
npm run build            # بناء للإنتاج
npm run preview          # معاينة الإنتاج محلياً
npm run deploy           # نشر تلقائي على Cloudflare
npm run deploy:prod      # نشر مع اسم مشروع محدد
npm run clean-port       # تنظيف المنفذ 3000
npm run test             # اختبار بسيط بـ curl
npm run git:commit       # git add + commit سريع
npm run git:status       # عرض حالة Git
npm run git:log          # عرض سجل Git
```

---

## 🐛 استكشاف الأخطاء

### المشكلة: الملف لا يُقرأ بشكل صحيح
**الحل:**
- تأكد من أن الملف Excel يحتوي على ترويسة واضحة
- تحقق من أسماء الأعمدة (يجب أن تحتوي على كلمات مثل "تاريخ"، "مبلغ"، "بيان")
- جرب تحويل PDF إلى Excel أولاً

### المشكلة: جميع السجلات "غير مطابقة"
**الحل:**
- تحقق من تطابق العملة في الملفين
- تأكد من أن التواريخ بنفس التنسيق
- راجع أن المبالغ متطابقة رقمياً

### المشكلة: النظام بطيء
**الحل:**
- قلل عدد السجلات (< 2000 سجل لكل ملف)
- استخدم متصفح حديث (Chrome, Edge, Firefox)
- أغلق التطبيقات الأخرى المستهلكة للذاكرة

---

## 🔮 الميزات المستقبلية

- [ ] دعم كامل لملفات PDF (استخراج الجداول تلقائياً)
- [ ] دعم CSV و TXT
- [ ] مقارنة أكثر من ملفين في نفس الوقت
- [ ] حفظ التقارير في السحابة (اختياري)
- [ ] تكامل مع أنظمة ERP (SAP, Oracle)
- [ ] تصدير Excel للتقارير
- [ ] واجهة API للمطورين
- [ ] دعم لغات إضافية (إنجليزي، فرنسي)

---

## 📄 الترخيص

هذا المشروع مفتوح المصدر ومتاح للاستخدام الشخصي والتجاري.

---

## 👨‍💻 المطور

تم تطويره باستخدام:
- **Hono Framework** - إطار عمل خفيف وسريع
- **Cloudflare Pages** - نشر على الحافة (Edge)
- **SheetJS** - معالجة Excel
- **Tailwind CSS** - تصميم سريع واحترافي

---

## 🙏 الدعم

إذا واجهت أي مشكلة أو لديك اقتراح، يرجى فتح Issue على GitHub.

---

**نسخة:** 1.0.0  
**آخر تحديث:** 2025-11-03  
**الحالة:** ✅ نشط ويعمل

---

## ⚡ Quick Start

```bash
# Clone, Install, Build, Run
git clone <repo>
cd webapp
npm install
npm run build
pm2 start ecosystem.config.cjs

# Test
curl http://localhost:3000/api/health

# Deploy
npm run deploy:prod
```

🎉 **استمتع باستخدام FinMatch!**
