import { Hono } from 'hono'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// Main page
app.get('/', (c) => {
  return c.html(`
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FinMatch - نظام مقارنة الكشوفات المالية</title>
    <meta name="description" content="نظام ذكي لمقارنة الكشوفات المالية (Excel/PDF) وإنتاج تقارير دقيقة">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <link href="/static/style.css" rel="stylesheet">
    
    <!-- SheetJS for Excel parsing -->
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <!-- Header -->
    <header class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-4 py-6">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <div class="bg-blue-600 text-white rounded-lg p-3">
                        <i class="fas fa-chart-bar text-2xl"></i>
                    </div>
                    <div>
                        <h1 class="text-3xl font-bold text-gray-800">FinMatch</h1>
                        <p class="text-gray-600 text-sm">نظام مقارنة الكشوفات المالية</p>
                    </div>
                </div>
                <div class="flex gap-2">
                    <a href="https://github.com" target="_blank" class="text-gray-600 hover:text-blue-600 transition">
                        <i class="fab fa-github text-2xl"></i>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 py-8">
        <!-- Info Banner -->
        <div class="bg-blue-600 text-white rounded-lg p-6 mb-8 shadow-lg">
            <div class="flex items-start gap-4">
                <i class="fas fa-info-circle text-3xl"></i>
                <div>
                    <h2 class="text-xl font-bold mb-2">كيف يعمل النظام؟</h2>
                    <ul class="space-y-1 text-sm">
                        <li>✓ ارفع ملفي Excel يحتويان على كشوفات مالية</li>
                        <li>✓ يقوم النظام بتحليل السجلات ومقارنتها وفق 6 معايير صارمة</li>
                        <li>✓ يتم المعالجة بالكامل في متصفحك (خصوصية تامة - لا رفع للسيرفر)</li>
                        <li>✓ احصل على تقرير مفصل بالعمليات غير المطابقة</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- File Upload Section -->
        <div class="grid md:grid-cols-2 gap-6 mb-8">
            <!-- File 1 -->
            <div class="bg-white rounded-lg shadow-lg p-6 file-upload-area">
                <label class="block mb-4">
                    <div class="flex items-center gap-2 mb-2">
                        <i class="fas fa-file-excel text-green-600 text-xl"></i>
                        <span class="text-lg font-semibold text-gray-800">الكشف الأول</span>
                    </div>
                    <input 
                        type="file" 
                        id="file1" 
                        accept=".xlsx,.xls,.pdf" 
                        class="block w-full text-sm text-gray-500
                               file:mr-4 file:py-2 file:px-4
                               file:rounded-full file:border-0
                               file:text-sm file:font-semibold
                               file:bg-blue-50 file:text-blue-700
                               hover:file:bg-blue-100
                               cursor-pointer"
                    >
                </label>
                <div id="file1-status" class="text-sm text-gray-500 mt-2">
                    <i class="fas fa-upload"></i> لم يتم اختيار ملف
                </div>
            </div>

            <!-- File 2 -->
            <div class="bg-white rounded-lg shadow-lg p-6 file-upload-area">
                <label class="block mb-4">
                    <div class="flex items-center gap-2 mb-2">
                        <i class="fas fa-file-excel text-green-600 text-xl"></i>
                        <span class="text-lg font-semibold text-gray-800">الكشف الثاني</span>
                    </div>
                    <input 
                        type="file" 
                        id="file2" 
                        accept=".xlsx,.xls,.pdf" 
                        class="block w-full text-sm text-gray-500
                               file:mr-4 file:py-2 file:px-4
                               file:rounded-full file:border-0
                               file:text-sm file:font-semibold
                               file:bg-blue-50 file:text-blue-700
                               hover:file:bg-blue-100
                               cursor-pointer"
                    >
                </label>
                <div id="file2-status" class="text-sm text-gray-500 mt-2">
                    <i class="fas fa-upload"></i> لم يتم اختيار ملف
                </div>
            </div>
        </div>

        <!-- Compare Button -->
        <div class="text-center mb-8">
            <button 
                id="compareBtn" 
                disabled
                class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-8 rounded-lg 
                       shadow-lg transition-all transform hover:scale-105 disabled:opacity-50 
                       disabled:cursor-not-allowed disabled:transform-none"
            >
                <i class="fas fa-balance-scale mr-2"></i>
                بدء المقارنة
            </button>
        </div>

        <!-- Loading Indicator -->
        <div id="loading" class="hidden">
            <div class="bg-white rounded-lg shadow-lg p-8 text-center">
                <div class="spinner inline-block w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full mb-4"></div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">جاري المعالجة...</h3>
                <p id="loadingMessage" class="text-gray-600">الرجاء الانتظار</p>
                <div class="w-full bg-gray-200 rounded-full h-2 mt-4">
                    <div class="bg-blue-600 h-2 rounded-full progress-bar"></div>
                </div>
            </div>
        </div>

        <!-- Error Message -->
        <div id="errorMessage" class="hidden mb-8">
            <div class="bg-red-100 border-2 border-red-400 text-red-800 px-6 py-4 rounded-lg flex items-center gap-3">
                <i class="fas fa-exclamation-circle text-2xl"></i>
                <div>
                    <h4 class="font-bold mb-1">حدث خطأ</h4>
                    <p id="errorText"></p>
                </div>
            </div>
        </div>

        <!-- Results Section -->
        <div id="results" class="hidden fade-in">
            <!-- Summary Stats -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                    <i class="fas fa-chart-pie text-blue-600"></i>
                    ملخص النتائج
                </h2>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-blue-50 rounded-lg p-4 text-center">
                        <div class="text-3xl font-bold text-blue-600" id="totalRecords1">0</div>
                        <div class="text-sm text-gray-600 mt-1">سجلات الملف الأول</div>
                        <div class="text-xs text-gray-500 mt-1" id="file1Name"></div>
                    </div>
                    <div class="bg-purple-50 rounded-lg p-4 text-center">
                        <div class="text-3xl font-bold text-purple-600" id="totalRecords2">0</div>
                        <div class="text-sm text-gray-600 mt-1">سجلات الملف الثاني</div>
                        <div class="text-xs text-gray-500 mt-1" id="file2Name"></div>
                    </div>
                    <div class="bg-green-50 rounded-lg p-4 text-center">
                        <div class="text-3xl font-bold text-green-600" id="matchingCount">0</div>
                        <div class="text-sm text-gray-600 mt-1">سجلات متطابقة</div>
                    </div>
                    <div class="bg-red-50 rounded-lg p-4 text-center">
                        <div class="text-3xl font-bold text-red-600" id="nonMatchingCount">0</div>
                        <div class="text-sm text-gray-600 mt-1">سجلات غير متطابقة</div>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg p-4 text-center">
                        <div class="text-sm mb-1">نسبة المطابقة</div>
                        <div class="text-3xl font-bold" id="matchRate">0%</div>
                    </div>
                    <div class="bg-gray-100 rounded-lg p-4 text-center">
                        <div class="text-sm text-gray-600 mb-1">وقت المعالجة</div>
                        <div class="text-2xl font-bold text-gray-800" id="processingTime">0 ms</div>
                    </div>
                </div>

                <!-- Export Buttons -->
                <div class="flex gap-4 justify-center mt-6">
                    <button id="exportJson" class="bg-gray-800 hover:bg-gray-900 text-white px-6 py-2 rounded-lg transition">
                        <i class="fas fa-download mr-2"></i>
                        تصدير JSON
                    </button>
                    <button id="exportHtml" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                        <i class="fas fa-file-pdf mr-2"></i>
                        تصدير HTML
                    </button>
                </div>
            </div>

            <!-- Non-Matching Entries -->
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-2xl font-bold text-red-800 mb-6 flex items-center gap-2">
                    <i class="fas fa-exclamation-triangle"></i>
                    العمليات غير المطابقة
                </h2>
                <div id="nonMatchingList" class="space-y-6">
                    <!-- Will be populated by JavaScript -->
                </div>
            </div>
        </div>

        <!-- Matching Criteria Info -->
        <div class="bg-white rounded-lg shadow-lg p-6 mt-8">
            <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <i class="fas fa-list-check text-blue-600"></i>
                معايير المطابقة الستة
            </h3>
            <div class="grid md:grid-cols-2 gap-4">
                <div class="flex items-start gap-3">
                    <div class="bg-blue-100 text-blue-600 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">1</div>
                    <div>
                        <h4 class="font-semibold text-gray-800">مطابقة العملة</h4>
                        <p class="text-sm text-gray-600">يجب أن تكون العملة متطابقة 100% (USD, EUR, EGP...)</p>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <div class="bg-blue-100 text-blue-600 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">2</div>
                    <div>
                        <h4 class="font-semibold text-gray-800">مطابقة الطبيعة</h4>
                        <p class="text-sm text-gray-600">يجب أن تكون طبيعة المبلغ متطابقة (مدين أو دائن)</p>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <div class="bg-blue-100 text-blue-600 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">3</div>
                    <div>
                        <h4 class="font-semibold text-gray-800">مطابقة المبلغ</h4>
                        <p class="text-sm text-gray-600">يجب أن يكون المبلغ متطابقاً بدقة 100%</p>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <div class="bg-blue-100 text-blue-600 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">4</div>
                    <div>
                        <h4 class="font-semibold text-gray-800">فرق التاريخ</h4>
                        <p class="text-sm text-gray-600">يجب ألا يزيد الفرق عن 7 أيام</p>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <div class="bg-blue-100 text-blue-600 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">5</div>
                    <div>
                        <h4 class="font-semibold text-gray-800">تشابه نوع العملية</h4>
                        <p class="text-sm text-gray-600">يجب أن يكون التشابه ≥ 80% (استخدام خوارزمية Jaccard)</p>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <div class="bg-blue-100 text-blue-600 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">6</div>
                    <div>
                        <h4 class="font-semibold text-gray-800">تشابه البيان</h4>
                        <p class="text-sm text-gray-600">يجب أن يكون التشابه ≥ 50%</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-white shadow-md mt-12">
        <div class="max-w-7xl mx-auto px-4 py-6 text-center text-gray-600">
            <p class="mb-2">
                <i class="fas fa-code text-blue-600"></i>
                تم التطوير باستخدام <strong>Hono</strong> + <strong>Cloudflare Pages</strong> + <strong>SheetJS</strong>
            </p>
            <p class="text-sm">
                <i class="fas fa-lock text-green-600"></i>
                جميع البيانات تُعالج محلياً في متصفحك - لا يتم رفع أي ملفات للسيرفر
            </p>
        </div>
    </footer>

    <!-- Load Scripts -->
    <script src="/static/finmatch.js"></script>
    <script src="/static/app.js"></script>
</body>
</html>
  `)
})

// API endpoint (for future enhancements)
app.get('/api/health', (c) => {
  return c.json({
    status: 'ok',
    service: 'FinMatch',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  })
})

export default app
