// FinMatch - Financial Statement Comparison Engine
// Client-Side Processing (No Server Upload Required)

class FinMatch {
  constructor() {
    this.file1Data = null;
    this.file2Data = null;
  }

  // ========================================
  // FILE PARSING
  // ========================================

  async parseFile(file) {
    const fileType = file.name.split('.').pop().toLowerCase();
    
    if (fileType === 'xlsx' || fileType === 'xls') {
      return await this.parseExcel(file);
    } else if (fileType === 'pdf') {
      return await this.parsePDF(file);
    } else {
      throw new Error('نوع الملف غير مدعوم. الرجاء استخدام Excel أو PDF فقط.');
    }
  }

  async parseExcel(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
          const jsonData = XLSX.utils.sheet_to_json(firstSheet, { 
            header: 1,
            defval: '',
            blankrows: false
          });
          
          resolve(this.normalizeData(jsonData, file.name));
        } catch (error) {
          reject(new Error(`فشل تحليل ملف Excel: ${error.message}`));
        }
      };
      
      reader.onerror = () => reject(new Error('فشل قراءة الملف'));
      reader.readAsArrayBuffer(file);
    });
  }

  async parsePDF(file) {
    // For MVP, we'll ask users to convert PDF to Excel
    // Full PDF parsing requires complex table extraction
    throw new Error('معالجة PDF قيد التطوير. الرجاء تحويل الملف إلى Excel مؤقتاً.');
  }

  // ========================================
  // DATA NORMALIZATION
  // ========================================

  normalizeData(rawData, fileName) {
    if (!rawData || rawData.length === 0) {
      throw new Error('الملف فارغ أو لا يحتوي على بيانات صالحة');
    }

    // Find header row (skip empty rows and detect row with most filled cells)
    let headerRowIndex = 0;
    let maxFilledCells = 0;
    
    for (let i = 0; i < Math.min(10, rawData.length); i++) {
      const filledCells = rawData[i].filter(cell => cell && String(cell).trim()).length;
      if (filledCells > maxFilledCells) {
        maxFilledCells = filledCells;
        headerRowIndex = i;
      }
    }

    const headers = rawData[headerRowIndex].map(h => String(h).trim().toLowerCase());
    const dataRows = rawData.slice(headerRowIndex + 1);

    // Detect column mappings
    const columnMap = this.detectColumns(headers);
    
    // Extract currency from document (usually in header/title)
    const detectedCurrency = this.detectCurrency(rawData.slice(0, headerRowIndex));

    // Parse records
    const records = [];
    for (let i = 0; i < dataRows.length; i++) {
      const row = dataRows[i];
      
      // Skip empty rows
      if (!row || row.every(cell => !cell || String(cell).trim() === '')) {
        continue;
      }

      try {
        const record = this.parseRecord(row, columnMap, detectedCurrency);
        if (record && record.amount !== 0) {
          records.push({
            ...record,
            _rowIndex: headerRowIndex + i + 1,
            _sourceFile: fileName
          });
        }
      } catch (error) {
        console.warn(`تخطي السطر ${i + headerRowIndex + 2}: ${error.message}`);
      }
    }

    if (records.length === 0) {
      throw new Error('لم يتم العثور على سجلات صالحة في الملف');
    }

    return {
      fileName,
      records,
      totalRecords: records.length,
      detectedCurrency,
      columnMap
    };
  }

  detectColumns(headers) {
    const map = {
      date: -1,
      amount: -1,
      debit: -1,
      credit: -1,
      operationType: -1,
      description: -1,
      currency: -1,
      nature: -1
    };

    const patterns = {
      date: /تاريخ|date|تارىخ/i,
      amount: /مبلغ|amount|قيمة|value/i,
      debit: /مدين|debit|مصروف|expense/i,
      credit: /دائن|credit|ايراد|إيراد|revenue|income/i,
      operationType: /نوع|type|عملية|operation|طبيعة/i,
      description: /بيان|description|تفاصيل|details|وصف|ملاحظات|notes/i,
      currency: /عملة|currency|curr/i,
      nature: /طبيعة|nature|اتجاه|direction/i
    };

    headers.forEach((header, index) => {
      for (const [key, pattern] of Object.entries(patterns)) {
        if (pattern.test(header)) {
          map[key] = index;
        }
      }
    });

    // If debit/credit columns exist but not amount, we'll handle it specially
    if (map.amount === -1 && (map.debit !== -1 || map.credit !== -1)) {
      map.amount = 'debit_credit'; // Special marker
    }

    return map;
  }

  detectCurrency(headerRows) {
    const currencyPatterns = {
      'USD': /\$|usd|dollar/i,
      'EUR': /€|eur|euro/i,
      'EGP': /جنيه|egp|egyptian pound|ج\.م/i,
      'SAR': /ريال|sar|riyal|ر\.س/i,
      'AED': /درهم|aed|dirham|د\.إ/i
    };

    for (const row of headerRows) {
      const text = row.join(' ');
      for (const [currency, pattern] of Object.entries(currencyPatterns)) {
        if (pattern.test(text)) {
          return currency;
        }
      }
    }

    return null; // Will be detected from individual records
  }

  parseRecord(row, columnMap, defaultCurrency) {
    // Parse date
    let date = null;
    if (columnMap.date !== -1) {
      date = this.parseDate(row[columnMap.date]);
    }

    // Parse amount and nature (debit/credit)
    let amount = 0;
    let nature = null;

    if (columnMap.amount === 'debit_credit') {
      // Amount split into debit/credit columns
      const debitValue = columnMap.debit !== -1 ? this.parseNumber(row[columnMap.debit]) : 0;
      const creditValue = columnMap.credit !== -1 ? this.parseNumber(row[columnMap.credit]) : 0;

      if (debitValue !== 0) {
        amount = debitValue;
        nature = 'debit';
      } else if (creditValue !== 0) {
        amount = creditValue;
        nature = 'credit';
      }
    } else if (columnMap.amount !== -1) {
      amount = this.parseNumber(row[columnMap.amount]);
      
      // Detect nature from separate column or amount sign
      if (columnMap.nature !== -1) {
        const natureText = String(row[columnMap.nature]).toLowerCase();
        nature = natureText.includes('مدين') || natureText.includes('debit') ? 'debit' : 'credit';
      } else {
        nature = amount < 0 ? 'debit' : 'credit';
      }
    }

    // Parse operation type
    let operationType = '';
    if (columnMap.operationType !== -1) {
      operationType = String(row[columnMap.operationType] || '').trim();
    }

    // Parse description
    let description = '';
    if (columnMap.description !== -1) {
      description = String(row[columnMap.description] || '').trim();
    }

    // Parse currency
    let currency = defaultCurrency;
    if (columnMap.currency !== -1) {
      const currencyText = String(row[columnMap.currency] || '').trim();
      if (currencyText) {
        currency = currencyText;
      }
    }

    // Validate required fields
    if (!date) {
      throw new Error('التاريخ مفقود');
    }
    if (amount === 0) {
      throw new Error('المبلغ صفر');
    }

    return {
      date,
      amount: Math.abs(amount),
      nature,
      operationType,
      description,
      currency: currency || 'UNKNOWN'
    };
  }

  parseDate(value) {
    if (!value) return null;

    // Handle Excel serial date
    if (typeof value === 'number') {
      const date = new Date((value - 25569) * 86400 * 1000);
      return date;
    }

    // Handle string dates
    const str = String(value).trim();
    
    // Try ISO format
    let date = new Date(str);
    if (!isNaN(date.getTime())) {
      return date;
    }

    // Try common formats: DD/MM/YYYY, DD-MM-YYYY
    const parts = str.split(/[\/\-\.]/);
    if (parts.length === 3) {
      const day = parseInt(parts[0]);
      const month = parseInt(parts[1]) - 1;
      const year = parseInt(parts[2]);
      
      date = new Date(year, month, day);
      if (!isNaN(date.getTime())) {
        return date;
      }
    }

    return null;
  }

  parseNumber(value) {
    if (typeof value === 'number') {
      return value;
    }

    if (!value) return 0;

    // Remove currency symbols and thousands separators
    const cleaned = String(value)
      .replace(/[^\d.,\-]/g, '')
      .replace(/,/g, '');

    const num = parseFloat(cleaned);
    return isNaN(num) ? 0 : num;
  }

  // ========================================
  // COMPARISON ENGINE
  // ========================================

  compare(data1, data2) {
    const startTime = Date.now();
    const nonMatchingEntries = [];

    for (const record1 of data1.records) {
      const matchResult = this.findMatch(record1, data2.records);
      
      if (!matchResult.isMatch) {
        nonMatchingEntries.push({
          file1_entry: record1,
          file2_candidates: matchResult.candidates,
          failure_reasons: matchResult.failures
        });
      }
    }

    const processingTime = Date.now() - startTime;

    return {
      report_id: this.generateUUID(),
      timestamp: new Date().toISOString(),
      processing_time_ms: processingTime,
      file1_name: data1.fileName,
      file2_name: data2.fileName,
      total_records_file1: data1.totalRecords,
      total_records_file2: data2.totalRecords,
      matching_entries: data1.totalRecords - nonMatchingEntries.length,
      non_matching_entries: nonMatchingEntries,
      match_rate: ((data1.totalRecords - nonMatchingEntries.length) / data1.totalRecords * 100).toFixed(2) + '%'
    };
  }

  findMatch(record1, records2) {
    const candidates = [];
    let bestMatch = null;
    let bestScore = 0;

    for (const record2 of records2) {
      const comparison = this.compareRecords(record1, record2);
      
      candidates.push({
        record: record2,
        score: comparison.score,
        checks: comparison.checks
      });

      if (comparison.isMatch && comparison.score > bestScore) {
        bestMatch = record2;
        bestScore = comparison.score;
      }
    }

    // Sort candidates by score
    candidates.sort((a, b) => b.score - a.score);
    const topCandidates = candidates.slice(0, 3);

    if (bestMatch) {
      return {
        isMatch: true,
        matchedRecord: bestMatch,
        candidates: topCandidates,
        failures: {}
      };
    }

    // Extract failure reasons from best candidate
    const bestCandidate = topCandidates[0];
    const failures = {
      currency_mismatch: !bestCandidate.checks.currency,
      nature_mismatch: !bestCandidate.checks.nature,
      amount_mismatch: !bestCandidate.checks.amount,
      date_diff_exceeds_7_days: !bestCandidate.checks.date,
      operation_type_similarity_lt_80: !bestCandidate.checks.operationType,
      description_similarity_lt_50: !bestCandidate.checks.description
    };

    return {
      isMatch: false,
      candidates: topCandidates,
      failures
    };
  }

  compareRecords(record1, record2) {
    const checks = {
      currency: this.checkCurrency(record1, record2),
      nature: this.checkNature(record1, record2),
      amount: this.checkAmount(record1, record2),
      date: this.checkDate(record1, record2),
      operationType: this.checkOperationType(record1, record2),
      description: this.checkDescription(record1, record2)
    };

    const isMatch = Object.values(checks).every(check => check.pass);
    
    // Calculate weighted score
    const weights = {
      currency: 20,
      nature: 20,
      amount: 20,
      date: 15,
      operationType: 15,
      description: 10
    };

    let score = 0;
    for (const [key, check] of Object.entries(checks)) {
      score += check.similarity * weights[key];
    }

    return {
      isMatch,
      score,
      checks: Object.fromEntries(
        Object.entries(checks).map(([k, v]) => [k, v.pass])
      )
    };
  }

  checkCurrency(r1, r2) {
    const match = r1.currency === r2.currency;
    return {
      pass: match,
      similarity: match ? 1 : 0,
      details: `${r1.currency} vs ${r2.currency}`
    };
  }

  checkNature(r1, r2) {
    const match = r1.nature === r2.nature;
    return {
      pass: match,
      similarity: match ? 1 : 0,
      details: `${r1.nature} vs ${r2.nature}`
    };
  }

  checkAmount(r1, r2) {
    const match = Math.abs(r1.amount - r2.amount) < 0.01;
    const similarity = 1 - Math.min(Math.abs(r1.amount - r2.amount) / Math.max(r1.amount, r2.amount), 1);
    return {
      pass: match,
      similarity,
      details: `${r1.amount.toFixed(2)} vs ${r2.amount.toFixed(2)}`
    };
  }

  checkDate(r1, r2) {
    const diffDays = Math.abs((r1.date - r2.date) / (1000 * 60 * 60 * 24));
    const match = diffDays <= 7;
    const similarity = Math.max(1 - diffDays / 30, 0);
    return {
      pass: match,
      similarity,
      details: `${diffDays.toFixed(1)} أيام`
    };
  }

  checkOperationType(r1, r2) {
    const similarity = this.calculateStringSimilarity(r1.operationType, r2.operationType);
    return {
      pass: similarity >= 0.8,
      similarity,
      details: `${r1.operationType} vs ${r2.operationType}`
    };
  }

  checkDescription(r1, r2) {
    const similarity = this.calculateStringSimilarity(r1.description, r2.description);
    return {
      pass: similarity >= 0.5,
      similarity,
      details: `تشابه ${(similarity * 100).toFixed(0)}%`
    };
  }

  calculateStringSimilarity(str1, str2) {
    if (!str1 && !str2) return 1;
    if (!str1 || !str2) return 0;

    const s1 = str1.toLowerCase().trim();
    const s2 = str2.toLowerCase().trim();

    if (s1 === s2) return 1;

    // Jaccard similarity on word tokens
    const tokens1 = new Set(s1.split(/\s+/));
    const tokens2 = new Set(s2.split(/\s+/));

    const intersection = new Set([...tokens1].filter(x => tokens2.has(x)));
    const union = new Set([...tokens1, ...tokens2]);

    return intersection.size / union.size;
  }

  generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}

// Initialize global instance
window.finMatchEngine = new FinMatch();
