// FinMatch UI Controller

let currentReport = null;

// Initialize UI
document.addEventListener('DOMContentLoaded', () => {
  setupFileInputs();
  setupCompareButton();
  setupExportButtons();
});

function setupFileInputs() {
  const file1Input = document.getElementById('file1');
  const file2Input = document.getElementById('file2');

  file1Input.addEventListener('change', (e) => handleFileSelect(e, 'file1'));
  file2Input.addEventListener('change', (e) => handleFileSelect(e, 'file2'));
}

function handleFileSelect(event, fileId) {
  const file = event.target.files[0];
  if (!file) return;

  const statusEl = document.getElementById(`${fileId}-status`);
  const fileType = file.name.split('.').pop().toLowerCase();

  if (!['xlsx', 'xls', 'pdf'].includes(fileType)) {
    statusEl.innerHTML = '<i class="fas fa-times-circle text-red-500"></i> نوع ملف غير مدعوم';
    return;
  }

  statusEl.innerHTML = `<i class="fas fa-check-circle text-green-500"></i> ${file.name} (${formatFileSize(file.size)})`;
  
  // Enable compare button if both files selected
  const file1 = document.getElementById('file1').files[0];
  const file2 = document.getElementById('file2').files[0];
  document.getElementById('compareBtn').disabled = !(file1 && file2);
}

function setupCompareButton() {
  document.getElementById('compareBtn').addEventListener('click', async () => {
    await performComparison();
  });
}

async function performComparison() {
  const file1 = document.getElementById('file1').files[0];
  const file2 = document.getElementById('file2').files[0];

  if (!file1 || !file2) {
    showError('الرجاء اختيار كلا الملفين');
    return;
  }

  const loadingEl = document.getElementById('loading');
  const resultsEl = document.getElementById('results');
  const compareBtn = document.getElementById('compareBtn');

  try {
    // Show loading
    loadingEl.classList.remove('hidden');
    resultsEl.classList.add('hidden');
    compareBtn.disabled = true;

    // Parse files
    updateLoadingMessage('جاري تحليل الملف الأول...');
    const data1 = await window.finMatchEngine.parseFile(file1);
    
    updateLoadingMessage('جاري تحليل الملف الثاني...');
    const data2 = await window.finMatchEngine.parseFile(file2);

    updateLoadingMessage('جاري مقارنة السجلات...');
    const report = window.finMatchEngine.compare(data1, data2);

    currentReport = report;

    // Display results
    loadingEl.classList.add('hidden');
    displayResults(report);
    resultsEl.classList.remove('hidden');

  } catch (error) {
    loadingEl.classList.add('hidden');
    showError(error.message);
    compareBtn.disabled = false;
  }
}

function updateLoadingMessage(message) {
  document.getElementById('loadingMessage').textContent = message;
}

function displayResults(report) {
  document.getElementById('file1Name').textContent = report.file1_name;
  document.getElementById('file2Name').textContent = report.file2_name;
  document.getElementById('totalRecords1').textContent = report.total_records_file1;
  document.getElementById('totalRecords2').textContent = report.total_records_file2;
  document.getElementById('matchingCount').textContent = report.matching_entries;
  document.getElementById('nonMatchingCount').textContent = report.non_matching_entries.length;
  document.getElementById('matchRate').textContent = report.match_rate;
  document.getElementById('processingTime').textContent = `${report.processing_time_ms} مللي ثانية`;

  // Display non-matching entries
  const container = document.getElementById('nonMatchingList');
  container.innerHTML = '';

  if (report.non_matching_entries.length === 0) {
    container.innerHTML = `
      <div class="bg-green-50 border border-green-200 rounded-lg p-8 text-center">
        <i class="fas fa-check-circle text-green-500 text-5xl mb-4"></i>
        <h3 class="text-xl font-bold text-green-800 mb-2">مطابقة تامة!</h3>
        <p class="text-green-600">جميع السجلات متطابقة بنسبة 100%</p>
      </div>
    `;
    return;
  }

  report.non_matching_entries.forEach((entry, index) => {
    const card = createNonMatchingCard(entry, index + 1);
    container.appendChild(card);
  });
}

function createNonMatchingCard(entry, index) {
  const card = document.createElement('div');
  card.className = 'bg-white border-2 border-red-200 rounded-lg p-6 hover:shadow-lg transition-shadow';

  const record = entry.file1_entry;
  const failures = entry.failure_reasons;
  const candidate = entry.file2_candidates[0];

  card.innerHTML = `
    <div class="flex items-start justify-between mb-4">
      <h4 class="text-lg font-bold text-gray-800">
        <i class="fas fa-exclamation-triangle text-red-500 mr-2"></i>
        سجل غير مطابق #${index}
      </h4>
      <span class="text-sm text-gray-500">السطر ${record._rowIndex}</span>
    </div>

    <!-- Original Record -->
    <div class="bg-blue-50 rounded-lg p-4 mb-4">
      <h5 class="font-semibold text-blue-800 mb-2">السجل الأصلي (${record._sourceFile})</h5>
      <div class="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
        <div><span class="font-medium">التاريخ:</span> ${formatDate(record.date)}</div>
        <div><span class="font-medium">المبلغ:</span> ${record.amount.toFixed(2)} ${record.currency}</div>
        <div><span class="font-medium">الطبيعة:</span> ${record.nature === 'debit' ? 'مدين' : 'دائن'}</div>
        <div class="col-span-2"><span class="font-medium">نوع العملية:</span> ${record.operationType || '-'}</div>
        <div class="col-span-3"><span class="font-medium">البيان:</span> ${record.description || '-'}</div>
      </div>
    </div>

    <!-- Best Candidate -->
    ${candidate ? `
      <div class="bg-gray-50 rounded-lg p-4 mb-4">
        <h5 class="font-semibold text-gray-800 mb-2">
          أقرب تطابق (درجة: ${candidate.score.toFixed(1)}/100)
        </h5>
        <div class="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
          <div><span class="font-medium">التاريخ:</span> ${formatDate(candidate.record.date)}</div>
          <div><span class="font-medium">المبلغ:</span> ${candidate.record.amount.toFixed(2)} ${candidate.record.currency}</div>
          <div><span class="font-medium">الطبيعة:</span> ${candidate.record.nature === 'debit' ? 'مدين' : 'دائن'}</div>
          <div class="col-span-2"><span class="font-medium">نوع العملية:</span> ${candidate.record.operationType || '-'}</div>
          <div class="col-span-3"><span class="font-medium">البيان:</span> ${candidate.record.description || '-'}</div>
        </div>
      </div>
    ` : ''}

    <!-- Failure Reasons -->
    <div class="border-t pt-4">
      <h5 class="font-semibold text-red-800 mb-3">أسباب عدم المطابقة:</h5>
      <div class="space-y-2">
        ${failures.currency_mismatch ? '<div class="flex items-center text-sm text-red-600"><i class="fas fa-times-circle mr-2"></i> عدم تطابق العملة</div>' : ''}
        ${failures.nature_mismatch ? '<div class="flex items-center text-sm text-red-600"><i class="fas fa-times-circle mr-2"></i> عدم تطابق الطبيعة (مدين/دائن)</div>' : ''}
        ${failures.amount_mismatch ? '<div class="flex items-center text-sm text-red-600"><i class="fas fa-times-circle mr-2"></i> عدم تطابق المبلغ</div>' : ''}
        ${failures.date_diff_exceeds_7_days ? '<div class="flex items-center text-sm text-red-600"><i class="fas fa-times-circle mr-2"></i> فرق التاريخ أكثر من 7 أيام</div>' : ''}
        ${failures.operation_type_similarity_lt_80 ? '<div class="flex items-center text-sm text-red-600"><i class="fas fa-times-circle mr-2"></i> تشابه نوع العملية أقل من 80%</div>' : ''}
        ${failures.description_similarity_lt_50 ? '<div class="flex items-center text-sm text-red-600"><i class="fas fa-times-circle mr-2"></i> تشابه البيان أقل من 50%</div>' : ''}
      </div>
    </div>
  `;

  return card;
}

function setupExportButtons() {
  document.getElementById('exportJson').addEventListener('click', () => {
    if (!currentReport) return;
    exportAsJSON();
  });

  document.getElementById('exportHtml').addEventListener('click', () => {
    if (!currentReport) return;
    exportAsHTML();
  });
}

function exportAsJSON() {
  const dataStr = JSON.stringify(currentReport, null, 2);
  const blob = new Blob([dataStr], { type: 'application/json' });
  downloadFile(blob, `finmatch-report-${Date.now()}.json`);
}

function exportAsHTML() {
  const html = generateHTMLReport(currentReport);
  const blob = new Blob([html], { type: 'text/html; charset=utf-8' });
  downloadFile(blob, `finmatch-report-${Date.now()}.html`);
}

function generateHTMLReport(report) {
  return `
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>تقرير FinMatch - ${report.report_id}</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    @media print {
      .no-print { display: none; }
    }
  </style>
</head>
<body class="bg-gray-50 p-8" dir="rtl">
  <div class="max-w-6xl mx-auto bg-white rounded-lg shadow-lg p-8">
    <div class="text-center mb-8">
      <h1 class="text-3xl font-bold text-blue-600 mb-2">
        <i class="fas fa-chart-bar mr-2"></i>
        تقرير مقارنة الكشوفات المالية
      </h1>
      <p class="text-gray-600">معرف التقرير: ${report.report_id}</p>
      <p class="text-gray-500 text-sm">${new Date(report.timestamp).toLocaleString('ar-EG')}</p>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <div class="bg-blue-50 rounded-lg p-4 text-center">
        <div class="text-2xl font-bold text-blue-600">${report.total_records_file1}</div>
        <div class="text-sm text-gray-600">سجلات الملف الأول</div>
      </div>
      <div class="bg-green-50 rounded-lg p-4 text-center">
        <div class="text-2xl font-bold text-green-600">${report.matching_entries}</div>
        <div class="text-sm text-gray-600">سجلات متطابقة</div>
      </div>
      <div class="bg-red-50 rounded-lg p-4 text-center">
        <div class="text-2xl font-bold text-red-600">${report.non_matching_entries.length}</div>
        <div class="text-sm text-gray-600">سجلات غير متطابقة</div>
      </div>
      <div class="bg-purple-50 rounded-lg p-4 text-center">
        <div class="text-2xl font-bold text-purple-600">${report.match_rate}</div>
        <div class="text-sm text-gray-600">نسبة المطابقة</div>
      </div>
    </div>

    <div class="space-y-4">
      ${report.non_matching_entries.map((entry, index) => `
        <div class="border-2 border-red-200 rounded-lg p-4">
          <h3 class="font-bold text-red-800 mb-2">سجل غير مطابق #${index + 1}</h3>
          <div class="text-sm">
            <strong>التاريخ:</strong> ${formatDate(entry.file1_entry.date)} |
            <strong>المبلغ:</strong> ${entry.file1_entry.amount.toFixed(2)} ${entry.file1_entry.currency} |
            <strong>البيان:</strong> ${entry.file1_entry.description}
          </div>
        </div>
      `).join('')}
    </div>

    <div class="mt-8 text-center text-gray-500 text-sm no-print">
      <p>تم الإنشاء بواسطة FinMatch - نظام مقارنة الكشوفات المالية</p>
    </div>
  </div>
</body>
</html>
  `;
}

function downloadFile(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function formatDate(date) {
  if (!date) return '-';
  const d = new Date(date);
  return d.toLocaleDateString('ar-EG');
}

function formatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

function showError(message) {
  const errorEl = document.getElementById('errorMessage');
  const errorText = document.getElementById('errorText');
  errorText.textContent = message;
  errorEl.classList.remove('hidden');
  
  setTimeout(() => {
    errorEl.classList.add('hidden');
  }, 5000);
}
